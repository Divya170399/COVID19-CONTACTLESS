# Covid-Doctor
This website is made to help people testify if they are having corona virus or not by not going to the hospital or any laboratory.
